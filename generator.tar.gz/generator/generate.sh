# run generator with path as argument
java -jar ./generator.jar $1